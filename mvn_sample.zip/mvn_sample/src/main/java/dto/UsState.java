package dto;

/**
 * @author ztang
 * generated at : Mar 9, 2015 - 10:06:58 PM
 */
public class UsState {

	public UsState() {
		super();
	}
	/*
	private String address1;	
	public String getAddress1() {	return address1;	}
	public void setAddress1(String address) {	this.address1 = address;	}
	
	private String address2;
	public String getAddress2() {	return address2;	}
	public void setAddress2(String address2) {	this.address2 = address2;	}

	private String city;
	public String getCity() {	return this.city;	}
	public void setCity(String city) {	this.city = city;	}
	
	private String zip;
	public String getZip() {	return this.zip;	}
	public void setZip(String zip) {	this.zip = zip;	}
	*/
	private String name;
	public String getName() {	return name;	}
	public void setName(String name) {	this.name = name;	}	
	
	private String code;
	public String getCode() {	return code;	}
	public void setCode(String code) {	this.code = code;	}
	


}
